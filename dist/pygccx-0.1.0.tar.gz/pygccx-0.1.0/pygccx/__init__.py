__version__ = '0.1.0'
__author__ = 'Matthias Sedlmaier'
__author_email__='winterheart@gmx.de'