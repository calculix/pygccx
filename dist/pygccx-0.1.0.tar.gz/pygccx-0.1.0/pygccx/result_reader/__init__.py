from .frd_result import FrdResult
from .dat_result import DatResult